appname="NeLuaJ+"
debug_mode=true