import JavaEditor "com.open.lua.widget.JavaEditor"

return {
  JavaEditor,
  id="mEditor",
}