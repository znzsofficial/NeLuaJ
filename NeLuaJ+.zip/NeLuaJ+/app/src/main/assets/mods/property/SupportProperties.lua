local _M = {}
-- 保存支持信息，方便后续的兼容性完善

_M.NIO = true

_M.Magnifier = true

return _M