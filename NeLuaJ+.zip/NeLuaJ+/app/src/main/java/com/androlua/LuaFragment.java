package com.androlua;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import org.luaj.LuaError;
import org.luaj.LuaTable;
import org.luaj.LuaValue;

@SuppressLint("ValidFragment")
public class LuaFragment extends Fragment {

  private LuaTable mLayout = null;
  private LuaTable mEnv = null;
  private View mView = null;

  public static LuaFragment newInstance(LuaTable layout) {
    return new LuaFragment(layout);
  }

  public static LuaFragment newInstance(View view) {
    return new LuaFragment(view);
  }

  public LuaFragment(LuaTable layout) {
    mLayout = layout;
  }

  public LuaFragment(View view) {
    mView = view;
  }

  public LuaFragment() {}

  public void setLayout(LuaTable layout) {
    mLayout = layout;
  }

  public void setLayout(View view) {
    mView = view;
  }

  @Override
  public View onCreateView(
      LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    try {
      if (mView != null) {
        return mView;
      }
      mEnv = new LuaTable();
      return new LuaLayout(getActivity()).load(mLayout, mEnv).touserdata(View.class);
    } catch (LuaError e) {
      throw new IllegalArgumentException(e.getMessage());
    }
  }

  public LuaValue getView(String id) {
    if (mEnv == null) return null;
    return mEnv.get(id);
  }
}
