package com.androlua;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.activity.ComponentActivity;
import androidx.core.os.HandlerCompat;
import androidx.core.splashscreen.SplashScreen;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
// import net.lingala.zip4j.ZipFile;
// import net.lingala.zip4j.exception.ZipException;

public class SplashWelcome extends ComponentActivity {

  private boolean isUpdata;
  private LuaApplication app;
  private String localDir;
  private long mLastTime;
  private long mOldLastTime;
  private boolean isVersionChanged;
  private String mVersionName;
  private String mOldVersionName;
  private ArrayList<String> permissions;

  @CallLuaFunction
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    // LinearLayout layout = new LinearLayout(this);
    SplashScreen.installSplashScreen(this);
    // setContentView(layout);
    app = (LuaApplication) getApplication();
    localDir = app.getLuaDir();
    /*try {
        if (new File(app.getLuaPath("setup.png")).exists())
            getWindow().setBackgroundDrawable(new LuaBitmapDrawable(app, app.getLuaPath("setup.png"), getResources().getDrawable(R.drawable.icon)));
    } catch (Exception e) {
        e.printStackTrace();
    }*/
    if (checkInfo()) {
      LuaApplication.getInstance().setSharedData("UnZiped", false);
      ExecutorService executor = Executors.newSingleThreadExecutor();
      Handler handler = HandlerCompat.createAsync(Looper.getMainLooper());

      executor.execute(
          () -> {
            try {
              unApk("assets/", localDir);
            } catch (IOException e) {
              e.printStackTrace();
            }
            handler.post(
                () -> {
                  startActivity();
                  LuaApplication.getInstance().setSharedData("UnZiped", true);
                });
          });
      executor.shutdown();
    } else {
      startActivity();
    }
  }

  public void startActivity() {
    try {
      InputStream f = getAssets().open("main.lua");
      if (f != null) {
        Intent intent = new Intent(SplashWelcome.this, LuaActivity.class);
        if (isVersionChanged) {
          intent.putExtra("isVersionChanged", isVersionChanged);
          intent.putExtra("newVersionName", mVersionName);
          intent.putExtra("oldVersionName", mOldVersionName);
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
        return;
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    // overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out
    //
    // );
    finish();
  }

  public boolean checkInfo() {
    try {
      PackageInfo packageInfo = getPackageManager().getPackageInfo(this.getPackageName(), 0);
      long lastTime = packageInfo.lastUpdateTime;
      String versionName = packageInfo.versionName;
      SharedPreferences info = getSharedPreferences("appInfo", 0);
      String oldVersionName = info.getString("versionName", "");
      mVersionName = versionName;
      mOldVersionName = oldVersionName;
      if (!versionName.equals(oldVersionName)) {
        SharedPreferences.Editor edit = info.edit();
        edit.putString("versionName", versionName);
        edit.apply();
        isVersionChanged = true;
      }
      long oldLastTime = info.getLong("lastUpdateTime", 0);
      if (oldLastTime != lastTime) {
        SharedPreferences.Editor edit = info.edit();
        edit.putLong("lastUpdateTime", lastTime);
        edit.apply();
        isUpdata = true;
        mLastTime = lastTime;
        mOldLastTime = oldLastTime;
        return true;
      }
    } catch (PackageManager.NameNotFoundException e) {
      e.printStackTrace();
    }
    return false;
  }

  /*
  private void unApk(String dir, String extDir) throws ZipException {
    File file = new File(extDir);
    String tempDir = getCacheDir().getPath();
    rmDir(file);
    ZipFile zipFile = new ZipFile(getApplicationInfo().publicSourceDir);
    zipFile.extractFile(dir, tempDir);
    new File(tempDir + "/" + dir).renameTo(file);
  }

  private void rmDir(File file, String str) {
    if (file.isDirectory()) {
      for (File file2 : file.listFiles()) {
        rmDir(file2, str);
      }
      file.delete();
    }
    if (file.getName().endsWith(str)) {
      file.delete();
    }
  }

  private boolean rmDir(File file) {
    if (file.isDirectory()) {
      for (File file2 : file.listFiles()) {
        rmDir(file2);
      }
    }
    return file.delete();
  }
  */
  private ZipFile zipFile;
  private String destPath;

  public void unApk(String dir, String extDir) throws IOException {
    ArrayList<String> dirtest = new ArrayList<String>();
    ExecutorService threadPool =
        Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
    int i = dir.length();
    this.destPath = extDir;
    zipFile = new ZipFile(getApplicationInfo().publicSourceDir);
    Enumeration<? extends ZipEntry> entries = zipFile.entries();
    ArrayList<ZipEntry> inzipfile = new ArrayList<ZipEntry>();
    while (entries.hasMoreElements()) {
      ZipEntry zipEntry = entries.nextElement();
      String name = zipEntry.getName();
      if (name.indexOf(dir) != 0) continue;
      String path = name.substring(i);
      String fp = extDir + File.separator + path;
      if (!zipEntry.isDirectory()) {
        inzipfile.add(zipEntry);
        dirtest.add(fp + File.separator);
        continue;
      }
      File file = new File(fp);
      if (!file.exists()) {
        file.mkdirs();
      }
    }
    Iterator<ZipEntry> iter = inzipfile.iterator();
    while (iter.hasNext()) { // 文件处理
      ZipEntry zipEntry = iter.next();
      String name = zipEntry.getName();
      String path = name.substring(i);
      String fp = extDir + File.separator + path;
      Iterator<String> watchiter = dirtest.iterator();
      boolean find = false;
      while (watchiter.hasNext()) {
        String dirtestwatchn = watchiter.next();
        if (fp.startsWith(dirtestwatchn)) {
          find = true;
          break;
        }
      }
      if (find) continue;
      threadPool.execute(new FileWritingTask(zipEntry, path));
    }
    threadPool.shutdown();
    try {
      threadPool.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
    } catch (InterruptedException e) {
      e.printStackTrace();
      throw new RuntimeException("ExecutorService was interrupted.");
    }
    zipFile.close();
  }

  private class FileWritingTask implements Runnable {
    private final ZipEntry zipEntry;
    private final String path;

    FileWritingTask(ZipEntry zipEntry, String path) {
      this.zipEntry = zipEntry;
      this.path = path;
    }

    @Override
    public void run() {
      File file = new File(destPath + File.separator + path);
      if (file.exists() && file.isDirectory()) { // 保证文件写入，文件夹就算了……
        LuaUtil.rmDir(file);
      }
      File parentFile = file.getParentFile();
      if (!parentFile.exists()) {
        parentFile.mkdirs();
      }
      if (parentFile.isDirectory()) {
        try {
          InputStream inputStream = zipFile.getInputStream(this.zipEntry);
          OutputStream outputStream = new FileOutputStream(file);
          byte[] buffer = new byte[2048];
          int n;
          while ((n = inputStream.read(buffer)) >= 0) {
            outputStream.write(buffer, 0, n);
          }
          outputStream.close();
        } catch (IOException e) {
          e.printStackTrace();
          throw new RuntimeException("unzip error at file " + file.getAbsolutePath() + ".");
        }
      } else {
        throw new RuntimeException(
            "ParentFile( path = \""
                + parentFile.getAbsolutePath()
                + "\" ) is not a directory, the application can't write the File( name = \""
                + file.getName()
                + "\" ) in a file.");
      }
    }
  }
}
