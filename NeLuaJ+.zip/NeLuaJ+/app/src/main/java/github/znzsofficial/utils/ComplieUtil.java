package github.znzsofficial.utils;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import org.luaj.Globals;
import org.luaj.LuaClosure;
import org.luaj.LuaError;
import org.luaj.LuaValue;
import org.luaj.compiler.DumpState;
import org.luaj.lib.jse.JsePlatform;

public class ComplieUtil {
  private static Globals mGlobals = JsePlatform.standardGlobals();

  public static byte[] getByteArray(String path) {
    LuaClosure checkfunction = (LuaClosure) mGlobals.loadfile(path).checkfunction(1);
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    try {
      DumpState.dump(checkfunction.c, baos, true);
      return baos.toByteArray();
    } catch (Exception e) {
      throw new LuaError(e);
    }
  }

  public static void dump(String input, String output) {
    try {
      FileOutputStream fos = new FileOutputStream(output);
      fos.write(getByteArray(input));
      fos.close();
    } catch (IOException e) {
      throw new LuaError(e);
    }
  }
}
