package github.znzsofficial.widget.container;

import com.drakeet.drawer.FullDraggableContainer;
import android.content.Context;
import android.view.MotionEvent;

public class MyFullDraggableContainer extends FullDraggableContainer {
  private boolean isSwipeable = true;

  public MyFullDraggableContainer(Context context) {
    super(context);
  }

  // 重写 onInterceptTouchEvent 方法
  @Override
  public boolean onInterceptTouchEvent(MotionEvent event) {
    super.onInterceptTouchEvent(event);
    if (this.isSwipeable) {
      return this.onTouchEvent(event);
    }
    return false;
  }

  public void setSwipeable(boolean z) {
    this.isSwipeable = z;
  }
}
