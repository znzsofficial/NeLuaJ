package github.znzsofficial.adapter;

import androidx.annotation.NonNull;
import com.androlua.LuaContext;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import me.zhanghai.android.fastscroll.PopupTextProvider;

public class PopupRecyclerAdapter extends LuaCustRecyclerAdapter implements PopupTextProvider {
  public PopupCreator adapterCreator;

  public PopupRecyclerAdapter(@NonNull PopupCreator adapterCreator) {
    super(adapterCreator);
    this.adapterCreator = adapterCreator;
    mContext = null;
  }

  public PopupRecyclerAdapter(LuaContext context, @NonNull PopupCreator adapterCreator) {
    super(context, adapterCreator);
    this.adapterCreator = adapterCreator;
    mContext = context;
  }

  @Override
  public CharSequence getPopupText(int position) {
    return this.adapterCreator.getPopupText(position);
  }

  public interface PopupCreator extends LuaCustRecyclerAdapter.Creator {

    CharSequence getPopupText(int i);
  }
}
