package github.znzsofficial.adapter;

import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.androlua.LuaContext;

public class LuaCustRecyclerAdapter extends RecyclerView.Adapter {
  public Creator adapterCreator;
  public LuaContext mContext;

  public LuaCustRecyclerAdapter(@NonNull Creator creator) {
    adapterCreator = creator;
    mContext = null;
  }

  public LuaCustRecyclerAdapter(LuaContext context, @NonNull Creator creator) {
    adapterCreator = creator;
    mContext = context;
  }

  @Override
  public int getItemCount() {
    try {
      return (int) this.adapterCreator.getItemCount();
    } catch (Exception e) {
      e.printStackTrace();
      if (mContext != null) {
        mContext.sendError("RecyclerAdapter: getItemCount", e);
      }
      return 0;
    }
  }

  @Override
  public int getItemViewType(int i) {
    try {
      return (int) this.adapterCreator.getItemViewType(i);
    } catch (Exception e) {
      e.printStackTrace();
      if (mContext != null) {
        mContext.sendError("RecyclerAdapter: getItemViewType", e);
      }
      return -1;
    }
  }

  @Override
  public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
    try {
      this.adapterCreator.onBindViewHolder(viewHolder, i);
    } catch (Exception e) {
      e.printStackTrace();
      if (mContext != null) {
        mContext.sendError("RecyclerAdapter: onBindViewHolder", e);
      }
    }
  }

  @Override
  public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
    try {
      return this.adapterCreator.onCreateViewHolder(viewGroup, i);
    } catch (Exception e) {
      e.printStackTrace();
      if (mContext != null) {
        mContext.sendError("RecyclerAdapter: onCreateViewHolder", e);
      }
      return null;
    }
  }

  @Override
  public void onViewRecycled(RecyclerView.ViewHolder viewHolder) {
    try {
      this.adapterCreator.onViewRecycled(viewHolder);
    } catch (Exception e) {
      e.printStackTrace();
      if (mContext != null) {
        mContext.sendError("RecyclerAdapter: onViewRecycled", e);
      }
    }
  }

  public interface Creator {
    long getItemCount();

    long getItemViewType(int i);

    void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i);

    RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i);

    void onViewRecycled(RecyclerView.ViewHolder viewHolder);
  }
}
