package github.znzsofficial.adapter;

import androidx.annotation.NonNull;
import com.androlua.LuaContext;
import me.zhanghai.android.fastscroll.PopupTextProvider;

public class PopupRecyclerListAdapter extends RecyclerListAdapter implements PopupTextProvider {
  public PopupCreator adapterCreator;

  public PopupRecyclerListAdapter(@NonNull PopupCreator adapterCreator) {
    super(adapterCreator);
    this.adapterCreator = adapterCreator;
    mContext = null;
  }

  public PopupRecyclerListAdapter(LuaContext context, @NonNull PopupCreator adapterCreator) {
    super(context, adapterCreator);
    this.adapterCreator = adapterCreator;
    mContext = context;
  }

  @Override
  public CharSequence getPopupText(int position) {
    return this.adapterCreator.getPopupText(position);
  }

  public interface PopupCreator extends PopupRecyclerListAdapter.Creator {
    CharSequence getPopupText(int i);
  }
}
