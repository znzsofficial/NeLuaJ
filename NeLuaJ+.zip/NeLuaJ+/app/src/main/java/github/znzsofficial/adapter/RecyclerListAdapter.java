package github.znzsofficial.adapter;

import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import com.androlua.LuaContext;
import org.luaj.LuaTable;
import org.luaj.LuaValue;

public class RecyclerListAdapter extends ListAdapter<Object, RecyclerView.ViewHolder> {
  public final Creator adapterCreator;
  public LuaContext mContext;

  public RecyclerListAdapter(Creator creator) {
    super(new DiffCallback(creator));
    adapterCreator = creator;
    mContext = null;
  }

  public RecyclerListAdapter(LuaContext context, Creator creator) {
    super(new DiffCallback(creator));
    mContext = context;
    adapterCreator = creator;
  }

  @Override
  public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
    try {
      this.adapterCreator.onBindViewHolder(viewHolder, i);
    } catch (Exception e) {
      e.printStackTrace();
      if (mContext != null) {
        mContext.sendError("RecyclerListAdapter: onBindViewHolder", e);
      }
    }
  }

  @Override
  public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
    try {
      return this.adapterCreator.onCreateViewHolder(viewGroup, i);
    } catch (Exception e) {
      e.printStackTrace();
      if (mContext != null) {
        mContext.sendError("RecyclerListAdapter: onCreateViewHolder", e);
      }
      return null;
    }
  }

  @Override
  public void onViewRecycled(RecyclerView.ViewHolder viewHolder) {
    try {
      this.adapterCreator.onViewRecycled(viewHolder);
    } catch (Exception e) {
      e.printStackTrace();
      if (mContext != null) {
        mContext.sendError("RecyclerListAdapter: onViewRecycled", e);
      }
    }
  }

  @Override
  public int getItemCount() {
    try {
      return (int) this.adapterCreator.getItemCount();
    } catch (Exception e) {
      e.printStackTrace();
      if (mContext != null) {
        mContext.sendError("RecyclerListAdapter: getItemCount", e);
      }
      return 0;
    }
  }

  @Override
  public int getItemViewType(int i) {
    try {
      return (int) this.adapterCreator.getItemViewType(i);
    } catch (Exception e) {
      e.printStackTrace();
      if (mContext != null) {
        mContext.sendError("RecyclerListAdapter: getItemViewType", e);
      }
      return -1;
    }
  }

  static class DiffCallback extends DiffUtil.ItemCallback<Object> {
    private final Creator adapterCreator;

    public DiffCallback(Creator creator) {
      this.adapterCreator = creator;
    }

    @Override
    public boolean areItemsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
      return adapterCreator.areItemsTheSame(oldItem, newItem);
    }

    @Override
    public boolean areContentsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
      return adapterCreator.areContentsTheSame(oldItem, newItem);
    }
  }

  public interface Creator {
    long getItemCount();

    long getItemViewType(int i);

    void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i);

    RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i);

    void onViewRecycled(RecyclerView.ViewHolder viewHolder);

    boolean areItemsTheSame(@NonNull Object oldItem, @NonNull Object newItem);

    boolean areContentsTheSame(@NonNull Object oldItem, @NonNull Object newItem);
  }
}
