package github.znzsofficial.adapter;

import android.animation.Animator;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import jp.wasabeef.recyclerview.animators.holder.AnimateViewHolder;
import android.view.View;

public class AnimateRecyclerHolder extends LuaCustRecyclerHolder implements AnimateViewHolder {
  @NonNull public Creator creator;

  public AnimateRecyclerHolder(View itemView, Creator holderCreator) {
    super(itemView);
    this.creator = holderCreator;
  }

  @Override
  public void animateAddImpl(RecyclerView.ViewHolder holder, Animator.AnimatorListener listener) {
    creator.animateAddImpl(holder, listener);
    // 具体的添加动画逻辑
  }

  @Override
  public void animateRemoveImpl(
      RecyclerView.ViewHolder holder, Animator.AnimatorListener listener) {
    creator.animateRemoveImpl(holder, listener);
    // 具体的移除动画逻辑
  }

  @Override
  public void preAnimateAddImpl(RecyclerView.ViewHolder holder) {
    creator.preAnimateAddImpl(holder);
    // 添加动画之前的准备逻辑
  }

  @Override
  public void preAnimateRemoveImpl(RecyclerView.ViewHolder holder) {
    creator.preAnimateRemoveImpl(holder);
    // 移除动画之前的准备逻辑
  }

  public interface Creator {
    void animateAddImpl(RecyclerView.ViewHolder holder, Animator.AnimatorListener listener);

    void animateRemoveImpl(RecyclerView.ViewHolder holder, Animator.AnimatorListener listener);

    void preAnimateAddImpl(RecyclerView.ViewHolder holder);

    void preAnimateRemoveImpl(RecyclerView.ViewHolder holder);
  }
}
