package github.znzsofficial.adapter;

import android.view.View;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

public class LuaCustRecyclerHolder extends RecyclerView.ViewHolder {
  @Nullable public Object Tag;

  public LuaCustRecyclerHolder(View itemView) {
    super(itemView);
  }

  public Object getViews() {
    return this.Tag;
  }

  public void setViews(Object views) {
    this.Tag = views;
  }
}
